<?php
$page_title = "Profile";
require_once 'common/config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Fetch user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $address = sanitize($_POST['address']);
        
        $update_stmt = $conn->prepare("UPDATE users SET email = ?, phone = ?, address = ? WHERE id = ?");
        $update_stmt->bind_param("sssi", $email, $phone, $address, $user_id);
        
        if ($update_stmt->execute()) {
            $success = 'Profile updated successfully';
            // Refresh user data
            $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
        } else {
            $error = 'Failed to update profile';
        }
        $update_stmt->close();
    }
    
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Verify current password
        if (password_verify($current_password, $user['password'])) {
            if ($new_password === $confirm_password) {
                if (strlen($new_password) >= 6) {
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $pass_stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $pass_stmt->bind_param("si", $hashed_password, $user_id);
                    
                    if ($pass_stmt->execute()) {
                        $success = 'Password changed successfully';
                    } else {
                        $error = 'Failed to change password';
                    }
                    $pass_stmt->close();
                } else {
                    $error = 'Password must be at least 6 characters';
                }
            } else {
                $error = 'New passwords do not match';
            }
        } else {
            $error = 'Current password is incorrect';
        }
    }
}

require_once 'common/header.php';
?>

<div class="container mx-auto px-4 py-6 max-w-4xl">
    <h1 class="text-3xl font-bold mb-8">My Profile</h1>
    
    <?php if ($success): ?>
    <div class="bg-green-900/50 border border-green-700 text-green-100 px-4 py-3 rounded-lg mb-6">
        <i class="fas fa-check-circle mr-2"></i>
        <?php echo $success; ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="bg-red-900/50 border border-red-700 text-red-100 px-4 py-3 rounded-lg mb-6">
        <i class="fas fa-exclamation-circle mr-2"></i>
        <?php echo $error; ?>
    </div>
    <?php endif; ?>
    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Profile Info -->
        <div class="lg:col-span-2 space-y-8">
            <!-- Personal Info -->
            <div class="bg-gray-800 rounded-xl p-6">
                <h2 class="text-xl font-bold mb-6 flex items-center">
                    <i class="fas fa-user-circle mr-3 text-green-400"></i>
                    Personal Information
                </h2>
                
                <form method="POST">
                    <input type="hidden" name="update_profile" value="1">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div>
                            <label class="block text-sm font-medium mb-2">Username</label>
                            <input type="text" value="<?php echo htmlspecialchars($user['username']); ?>" 
                                   class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3" readonly>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-2">Email Address</label>
                            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required
                                   class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div>
                            <label class="block text-sm font-medium mb-2">Phone Number</label>
                            <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>"
                                   class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500"
                                   placeholder="01XXXXXXXXX">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-2">Member Since</label>
                            <input type="text" value="<?php echo date('d M Y', strtotime($user['created_at'])); ?>" 
                                   class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3" readonly>
                        </div>
                    </div>
                    
                    <div class="mb-6">
                        <label class="block text-sm font-medium mb-2">Address</label>
                        <textarea name="address" rows="3"
                                  class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500"
                                  placeholder="Enter your address"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                    </div>
                    
                    <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300">
                        <i class="fas fa-save mr-2"></i>Update Profile
                    </button>
                </form>
            </div>
            
            <!-- Change Password -->
            <div class="bg-gray-800 rounded-xl p-6">
                <h2 class="text-xl font-bold mb-6 flex items-center">
                    <i class="fas fa-lock mr-3 text-blue-400"></i>
                    Change Password
                </h2>
                
                <form method="POST">
                    <input type="hidden" name="change_password" value="1">
                    
                    <div class="space-y-6">
                        <div>
                            <label class="block text-sm font-medium mb-2">Current Password</label>
                            <input type="password" name="current_password" required
                                   class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium mb-2">New Password</label>
                                <input type="password" name="new_password" required
                                       class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium mb-2">Confirm New Password</label>
                                <input type="password" name="confirm_password" required
                                       class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                            </div>
                        </div>
                        
                        <div class="bg-blue-900/30 border border-blue-700 p-4 rounded-lg">
                            <h4 class="font-bold text-blue-300 mb-2"><i class="fas fa-info-circle mr-2"></i>Password Requirements</h4>
                            <ul class="text-blue-200 text-sm space-y-1">
                                <li>• Minimum 6 characters</li>
                                <li>• Use letters and numbers</li>
                                <li>• Avoid common passwords</li>
                            </ul>
                        </div>
                        
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition duration-300">
                            <i class="fas fa-key mr-2"></i>Change Password
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="space-y-6">
            <!-- User Stats -->
            <div class="bg-gray-800 rounded-xl p-6">
                <div class="text-center mb-6">
                    <div class="w-20 h-20 bg-gradient-to-r from-green-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-user text-white text-3xl"></i>
                    </div>
                    <h3 class="text-xl font-bold"><?php echo htmlspecialchars($user['username']); ?></h3>
                    <p class="text-gray-400 text-sm">Tour Enthusiast</p>
                </div>
                
                <?php
                // Get booking stats
                $stats_query = $conn->prepare("SELECT 
                    COUNT(CASE WHEN status = 'confirmed' THEN 1 END) as confirmed,
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
                    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled
                    FROM bookings WHERE user_id = ?");
                $stats_query->bind_param("i", $user_id);
                $stats_query->execute();
                $stats = $stats_query->get_result()->fetch_assoc();
                $stats_query->close();
                ?>
                
                <div class="space-y-4">
                    <div class="flex justify-between items-center">
                        <span class="text-gray-400">Confirmed Tours</span>
                        <span class="font-bold text-green-400"><?php echo $stats['confirmed']; ?></span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-gray-400">Pending Bookings</span>
                        <span class="font-bold text-yellow-400"><?php echo $stats['pending']; ?></span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-gray-400">Cancelled</span>
                        <span class="font-bold text-red-400"><?php echo $stats['cancelled']; ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="bg-gray-800 rounded-xl p-6">
                <h3 class="font-bold mb-4">Quick Actions</h3>
                <div class="space-y-3">
                    <a href="my-bookings.php" class="flex items-center p-3 bg-gray-700 hover:bg-gray-600 rounded-lg transition">
                        <div class="w-10 h-10 bg-blue-900 rounded-lg flex items-center justify-center mr-3">
                            <i class="fas fa-calendar-check text-blue-300"></i>
                        </div>
                        <div>
                            <div class="font-medium">My Bookings</div>
                            <div class="text-gray-400 text-sm">View all bookings</div>
                        </div>
                    </a>
                    
                    <a href="tours.php" class="flex items-center p-3 bg-gray-700 hover:bg-gray-600 rounded-lg transition">
                        <div class="w-10 h-10 bg-green-900 rounded-lg flex items-center justify-center mr-3">
                            <i class="fas fa-map-marked-alt text-green-300"></i>
                        </div>
                        <div>
                            <div class="font-medium">Browse Tours</div>
                            <div class="text-gray-400 text-sm">Find new adventures</div>
                        </div>
                    </a>
                </div>
            </div>
            
            <!-- Support -->
            <div class="bg-purple-900/30 border border-purple-700 rounded-xl p-6">
                <h3 class="font-bold mb-3 text-purple-300"><i class="fas fa-headset mr-2"></i>Need Help?</h3>
                <p class="text-sm text-gray-300 mb-4">Contact our 24/7 customer support</p>
                <a href="tel:<?php echo $settings['contact_phone']; ?>" class="inline-flex items-center text-purple-300">
                    <i class="fas fa-phone mr-2"></i>
                    <?php echo $settings['contact_phone']; ?>
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>