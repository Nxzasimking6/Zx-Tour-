<?php
$page_title = "Bookings Management";
require_once 'common/header.php';

$success = '';
$error = '';

// Handle booking status update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_status'])) {
        $booking_id = intval($_POST['booking_id']);
        $status = sanitize($_POST['status']);
        
        $stmt = $conn->prepare("UPDATE bookings SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $booking_id);
        
        if ($stmt->execute()) {
            // If confirmed, update payment status
            if ($status === 'confirmed') {
                $payment_stmt = $conn->prepare("UPDATE payments SET status = 'completed' WHERE booking_id = ?");
                $payment_stmt->bind_param("i", $booking_id);
                $payment_stmt->execute();
                $payment_stmt->close();
            }
            $success = 'Booking status updated successfully';
        } else {
            $error = 'Failed to update booking status';
        }
        $stmt->close();
    }
}

// Fetch all bookings with user and tour info
$bookings_query = "SELECT b.*, u.username, u.email, u.phone, t.title as tour_title 
                   FROM bookings b
                   JOIN users u ON b.user_id = u.id
                   JOIN tours t ON b.tour_id = t.id
                   ORDER BY b.created_at DESC";
$bookings_result = $conn->query($bookings_query);
?>

<div class="space-y-6">
    <?php if ($success): ?>
    <div class="bg-green-900/50 border border-green-700 text-green-100 px-4 py-3 rounded-lg">
        <i class="fas fa-check-circle mr-2"></i>
        <?php echo $success; ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="bg-red-900/50 border border-red-700 text-red-100 px-4 py-3 rounded-lg">
        <i class="fas fa-exclamation-circle mr-2"></i>
        <?php echo $error; ?>
    </div>
    <?php endif; ?>
    
    <!-- Bookings List -->
    <div class="bg-gray-800 rounded-xl p-6">
        <h2 class="text-xl font-bold mb-6">All Bookings</h2>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="border-b border-gray-700">
                        <th class="text-left py-3 px-4">Booking ID</th>
                        <th class="text-left py-3 px-4">User</th>
                        <th class="text-left py-3 px-4">Tour</th>
                        <th class="text-left py-3 px-4">Amount</th>
                        <th class="text-left py-3 px-4">Persons</th>
                        <th class="text-left py-3 px-4">Date</th>
                        <th class="text-left py-3 px-4">Status</th>
                        <th class="text-left py-3 px-4">Payment</th>
                        <th class="text-left py-3 px-4">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($booking = $bookings_result->fetch_assoc()): 
                        $status_color = $booking['status'] === 'confirmed' ? 'bg-green-900 text-green-100' : 
                                       ($booking['status'] === 'cancelled' ? 'bg-red-900 text-red-100' : 'bg-yellow-900 text-yellow-100');
                    ?>
                    <tr class="border-b border-gray-700/50 hover:bg-gray-700/30">
                        <td class="py-3 px-4 font-mono">#<?php echo str_pad($booking['id'], 6, '0', STR_PAD_LEFT); ?></td>
                        <td class="py-3 px-4">
                            <div class="font-medium"><?php echo htmlspecialchars($booking['username']); ?></div>
                            <div class="text-gray-400 text-sm"><?php echo htmlspecialchars($booking['email']); ?></div>
                        </td>
                        <td class="py-3 px-4"><?php echo htmlspecialchars(substr($booking['tour_title'], 0, 30)); ?>...</td>
                        <td class="py-3 px-4 font-bold">৳<?php echo number_format($booking['total_amount']); ?></td>
                        <td class="py-3 px-4"><?php echo $booking['persons']; ?></td>
                        <td class="py-3 px-4"><?php echo date('d/m/Y', strtotime($booking['booking_date'])); ?></td>
                        <td class="py-3 px-4">
                            <span class="<?php echo $status_color; ?> px-3 py-1 rounded-full text-xs">
                                <?php echo ucfirst($booking['status']); ?>
                            </span>
                        </td>
                        <td class="py-3 px-4">
                            <?php if ($booking['payment_method']): ?>
                            <span class="bg-blue-900 text-blue-100 px-3 py-1 rounded-full text-xs">
                                <?php echo ucfirst($booking['payment_method']); ?>
                            </span>
                            <?php else: ?>
                            <span class="bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-xs">
                                Pending
                            </span>
                            <?php endif; ?>
                        </td>
                        <td class="py-3 px-4">
                            <div class="flex space-x-2">
                                <button onclick="showBookingDetails(<?php echo htmlspecialchars(json_encode($booking)); ?>)" 
                                        class="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <form method="POST" class="inline">
                                    <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                                    <select name="status" onchange="this.form.submit()" 
                                            class="bg-gray-700 border border-gray-600 rounded px-2 py-1 text-xs">
                                        <option value="pending" <?php echo $booking['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                        <option value="confirmed" <?php echo $booking['status'] === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                                        <option value="cancelled" <?php echo $booking['status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                    </select>
                                    <input type="hidden" name="update_status" value="1">
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Booking Details Modal -->
<div id="bookingModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden items-center justify-center p-4">
    <div class="bg-gray-800 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div class="p-6 border-b border-gray-700">
            <div class="flex justify-between items-center">
                <h3 class="text-xl font-bold">Booking Details</h3>
                <button onclick="hideBookingDetails()" class="text-gray-400 hover:text-white">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
        </div>
        
        <div class="p-6" id="bookingDetails">
            <!-- Details will be loaded here -->
        </div>
    </div>
</div>

<script>
function showBookingDetails(booking) {
    const modal = document.getElementById('bookingModal');
    const details = document.getElementById('bookingDetails');
    
    const statusColor = booking.status === 'confirmed' ? 'bg-green-900 text-green-100' : 
                       (booking.status === 'cancelled' ? 'bg-red-900 text-red-100' : 'bg-yellow-900 text-yellow-100');
    
    details.innerHTML = `
        <div class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="bg-gray-700/50 p-4 rounded-lg">
                    <div class="text-sm text-gray-400 mb-1">Booking ID</div>
                    <div class="font-bold text-lg">#${String(booking.id).padStart(6, '0')}</div>
                </div>
                
                <div class="bg-gray-700/50 p-4 rounded-lg">
                    <div class="text-sm text-gray-400 mb-1">Status</div>
                    <span class="${statusColor} px-3 py-1 rounded-full text-sm">
                        ${booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                    </span>
                </div>
            </div>
            
            <div class="space-y-4">
                <h4 class="font-bold text-lg">User Information</h4>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <div class="text-sm text-gray-400">Username</div>
                        <div class="font-medium">${booking.username}</div>
                    </div>
                    <div>
                        <div class="text-sm text-gray-400">Email</div>
                        <div class="font-medium">${booking.email}</div>
                    </div>
                    <div>
                        <div class="text-sm text-gray-400">Phone</div>
                        <div class="font-medium">${booking.phone || 'Not provided'}</div>
                    </div>
                    <div>
                        <div class="text-sm text-gray-400">Booking Date</div>
                        <div class="font-medium">${new Date(booking.booking_date).toLocaleDateString()}</div>
                    </div>
                </div>
            </div>
            
            <div class="space-y-4">
                <h4 class="font-bold text-lg">Tour Information</h4>
                <div class="bg-gray-700/50 p-4 rounded-lg">
                    <div class="font-bold text-lg mb-2">${booking.tour_title}</div>
                    <div class="text-gray-300">Booking for ${booking.persons} person${booking.persons > 1 ? 's' : ''}</div>
                </div>
            </div>
            
            <div class="space-y-4">
                <h4 class="font-bold text-lg">Payment Information</h4>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-gray-700/50 p-4 rounded-lg">
                        <div class="text-sm text-gray-400 mb-1">Total Amount</div>
                        <div class="text-2xl font-bold text-green-400">৳${parseFloat(booking.total_amount).toLocaleString()}</div>
                    </div>
                    <div class="bg-gray-700/50 p-4 rounded-lg">
                        <div class="text-sm text-gray-400 mb-1">Payment Method</div>
                        <div class="font-medium">${booking.payment_method ? booking.payment_method.charAt(0).toUpperCase() + booking.payment_method.slice(1) : 'Pending'}</div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function hideBookingDetails() {
    const modal = document.getElementById('bookingModal');
    modal.classList.remove('flex');
    modal.classList.add('hidden');
}
</script>

<?php require_once 'common/bottom.php'; ?>