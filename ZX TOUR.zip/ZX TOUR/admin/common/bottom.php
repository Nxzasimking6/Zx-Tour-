        </main>
        
        <!-- Footer -->
        <footer class="bg-gray-800 border-t border-gray-700 px-6 py-4">
            <div class="text-center text-gray-500 text-sm">
                <p>Zx Tour FF Admin Panel &copy; <?php echo date('Y'); ?> | All Rights Reserved</p>
                <p class="mt-1">Version 1.0.0</p>
            </div>
        </footer>
    </div>
    
    <script>
        // Toggle mobile menu
        document.getElementById('menuToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
        
        // Disable right-click
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
            return false;
        });
        
        // Disable zoom
        document.addEventListener('wheel', function(e) {
            if (e.ctrlKey) {
                e.preventDefault();
            }
        }, { passive: false });
        
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && (e.key === '+' || e.key === '-' || e.key === '0')) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>