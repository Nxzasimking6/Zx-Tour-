<?php
$page_title = "Tours Management";
require_once 'common/header.php';

$success = '';
$error = '';

// Handle add/edit/delete tour
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_tour'])) {
        $title = sanitize($_POST['title']);
        $description = sanitize($_POST['description']);
        $destination = sanitize($_POST['destination']);
        $duration = sanitize($_POST['duration']);
        $price = floatval($_POST['price']);
        $discount_price = floatval($_POST['discount_price']);
        $available_seats = intval($_POST['available_seats']);
        $is_featured = isset($_POST['is_featured']) ? 1 : 0;
        
        $stmt = $conn->prepare("INSERT INTO tours (title, description, destination, duration, price, discount_price, available_seats, is_featured) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssddii", $title, $description, $destination, $duration, $price, $discount_price, $available_seats, $is_featured);
        
        if ($stmt->execute()) {
            $success = 'Tour added successfully';
        } else {
            $error = 'Failed to add tour';
        }
        $stmt->close();
    }
    
    if (isset($_POST['edit_tour'])) {
        $id = intval($_POST['id']);
        $title = sanitize($_POST['title']);
        $description = sanitize($_POST['description']);
        $destination = sanitize($_POST['destination']);
        $duration = sanitize($_POST['duration']);
        $price = floatval($_POST['price']);
        $discount_price = floatval($_POST['discount_price']);
        $available_seats = intval($_POST['available_seats']);
        $is_featured = isset($_POST['is_featured']) ? 1 : 0;
        
        $stmt = $conn->prepare("UPDATE tours SET title = ?, description = ?, destination = ?, duration = ?, 
                                price = ?, discount_price = ?, available_seats = ?, is_featured = ? 
                                WHERE id = ?");
        $stmt->bind_param("ssssddiii", $title, $description, $destination, $duration, $price, $discount_price, $available_seats, $is_featured, $id);
        
        if ($stmt->execute()) {
            $success = 'Tour updated successfully';
        } else {
            $error = 'Failed to update tour';
        }
        $stmt->close();
    }
    
    if (isset($_POST['delete_tour'])) {
        $id = intval($_POST['id']);
        $stmt = $conn->prepare("DELETE FROM tours WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $success = 'Tour deleted successfully';
        } else {
            $error = 'Failed to delete tour';
        }
        $stmt->close();
    }
}

// Fetch all tours
$tours_result = $conn->query("SELECT * FROM tours ORDER BY created_at DESC");

// Check if editing a tour
$edit_tour = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $stmt = $conn->prepare("SELECT * FROM tours WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $edit_tour = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}
?>

<div class="space-y-6">
    <?php if ($success): ?>
    <div class="bg-green-900/50 border border-green-700 text-green-100 px-4 py-3 rounded-lg">
        <i class="fas fa-check-circle mr-2"></i>
        <?php echo $success; ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="bg-red-900/50 border border-red-700 text-red-100 px-4 py-3 rounded-lg">
        <i class="fas fa-exclamation-circle mr-2"></i>
        <?php echo $error; ?>
    </div>
    <?php endif; ?>
    
    <!-- Add/Edit Tour Form -->
    <div class="bg-gray-800 rounded-xl p-6">
        <h2 class="text-xl font-bold mb-6"><?php echo $edit_tour ? 'Edit Tour' : 'Add New Tour'; ?></h2>
        
        <form method="POST">
            <?php if ($edit_tour): ?>
            <input type="hidden" name="id" value="<?php echo $edit_tour['id']; ?>">
            <input type="hidden" name="edit_tour" value="1">
            <?php else: ?>
            <input type="hidden" name="add_tour" value="1">
            <?php endif; ?>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <label class="block text-sm font-medium mb-2">Tour Title</label>
                    <input type="text" name="title" required 
                           value="<?php echo $edit_tour['title'] ?? ''; ?>"
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium mb-2">Destination</label>
                    <input type="text" name="destination" required 
                           value="<?php echo $edit_tour['destination'] ?? ''; ?>"
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
            </div>
            
            <div class="mb-6">
                <label class="block text-sm font-medium mb-2">Description</label>
                <textarea name="description" rows="3" required
                          class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500"><?php echo $edit_tour['description'] ?? ''; ?></textarea>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <div>
                    <label class="block text-sm font-medium mb-2">Duration</label>
                    <input type="text" name="duration" required 
                           value="<?php echo $edit_tour['duration'] ?? ''; ?>"
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500"
                           placeholder="e.g., 3 Days 2 Nights">
                </div>
                
                <div>
                    <label class="block text-sm font-medium mb-2">Regular Price (৳)</label>
                    <input type="number" name="price" step="0.01" required 
                           value="<?php echo $edit_tour['price'] ?? ''; ?>"
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium mb-2">Discount Price (৳)</label>
                    <input type="number" name="discount_price" step="0.01" required 
                           value="<?php echo $edit_tour['discount_price'] ?? ''; ?>"
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
                
                <div>
                    <label class="block text-sm font-medium mb-2">Available Seats</label>
                    <input type="number" name="available_seats" required 
                           value="<?php echo $edit_tour['available_seats'] ?? ''; ?>"
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
            </div>
            
            <div class="mb-6">
                <label class="flex items-center">
                    <input type="checkbox" name="is_featured" value="1" 
                           <?php echo ($edit_tour['is_featured'] ?? 0) ? 'checked' : ''; ?>
                           class="w-4 h-4 text-green-600 bg-gray-700 border-gray-600 rounded focus:ring-green-500">
                    <span class="ml-2 text-sm">Mark as Featured Tour</span>
                </label>
            </div>
            
            <div class="flex gap-3">
                <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-lg">
                    <i class="fas fa-save mr-2"></i><?php echo $edit_tour ? 'Update Tour' : 'Add Tour'; ?>
                </button>
                
                <?php if ($edit_tour): ?>
                <a href="tours.php" class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-6 rounded-lg">
                    <i class="fas fa-times mr-2"></i>Cancel
                </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <!-- Tours List -->
    <div class="bg-gray-800 rounded-xl p-6">
        <h2 class="text-xl font-bold mb-6">All Tours</h2>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="border-b border-gray-700">
                        <th class="text-left py-3 px-4">ID</th>
                        <th class="text-left py-3 px-4">Title</th>
                        <th class="text-left py-3 px-4">Destination</th>
                        <th class="text-left py-3 px-4">Price</th>
                        <th class="text-left py-3 px-4">Seats</th>
                        <th class="text-left py-3 px-4">Featured</th>
                        <th class="text-left py-3 px-4">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($tour = $tours_result->fetch_assoc()): ?>
                    <tr class="border-b border-gray-700/50 hover:bg-gray-700/30">
                        <td class="py-3 px-4">#<?php echo $tour['id']; ?></td>
                        <td class="py-3 px-4"><?php echo htmlspecialchars(substr($tour['title'], 0, 40)); ?></td>
                        <td class="py-3 px-4"><?php echo htmlspecialchars($tour['destination']); ?></td>
                        <td class="py-3 px-4">
                            <div class="font-bold text-green-400">৳<?php echo number_format($tour['discount_price']); ?></div>
                            <div class="text-gray-500 text-sm line-through">৳<?php echo number_format($tour['price']); ?></div>
                        </td>
                        <td class="py-3 px-4">
                            <span class="<?php echo $tour['available_seats'] > 5 ? 'bg-green-900 text-green-100' : 'bg-red-900 text-red-100'; ?> px-3 py-1 rounded-full text-xs">
                                <?php echo $tour['available_seats']; ?> seats
                            </span>
                        </td>
                        <td class="py-3 px-4">
                            <?php if ($tour['is_featured']): ?>
                            <span class="bg-yellow-900 text-yellow-100 px-3 py-1 rounded-full text-xs">
                                <i class="fas fa-star mr-1"></i>Featured
                            </span>
                            <?php else: ?>
                            <span class="bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-xs">
                                Regular
                            </span>
                            <?php endif; ?>
                        </td>
                        <td class="py-3 px-4">
                            <div class="flex space-x-2">
                                <a href="tours.php?edit=<?php echo $tour['id']; ?>" class="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form method="POST" class="inline">
                                    <input type="hidden" name="id" value="<?php echo $tour['id']; ?>">
                                    <button type="submit" name="delete_tour" 
                                            class="bg-red-600 hover:bg-red-700 text-white p-2 rounded"
                                            onclick="return confirm('Are you sure you want to delete this tour?')">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>