<?php
$page_title = "Dashboard";
require_once 'common/header.php';

// Get statistics
$stats = [];

// Total users
$result = $conn->query("SELECT COUNT(*) as count FROM users");
$stats['users'] = $result->fetch_assoc()['count'];

// Total tours
$result = $conn->query("SELECT COUNT(*) as count FROM tours");
$stats['tours'] = $result->fetch_assoc()['count'];

// Total bookings
$result = $conn->query("SELECT COUNT(*) as count FROM bookings");
$stats['bookings'] = $result->fetch_assoc()['count'];

// Total revenue
$result = $conn->query("SELECT SUM(total_amount) as total FROM bookings WHERE status = 'confirmed'");
$stats['revenue'] = $result->fetch_assoc()['total'] ?? 0;

// Recent bookings
$recent_bookings = $conn->query("SELECT b.*, u.username, t.title FROM bookings b 
                                 JOIN users u ON b.user_id = u.id 
                                 JOIN tours t ON b.tour_id = t.id 
                                 ORDER BY b.created_at DESC LIMIT 5");
?>

<div class="space-y-6">
    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div class="bg-gradient-to-r from-blue-900 to-blue-800 rounded-xl p-6">
            <div class="flex items-center justify-between">
                <div>
                    <div class="text-3xl font-bold"><?php echo $stats['users']; ?></div>
                    <div class="text-blue-200 text-sm mt-1">Total Users</div>
                </div>
                <div class="w-12 h-12 bg-blue-700 rounded-lg flex items-center justify-center">
                    <i class="fas fa-users text-2xl"></i>
                </div>
            </div>
            <div class="mt-4 text-blue-300 text-sm">
                <i class="fas fa-arrow-up mr-1"></i> Registered users
            </div>
        </div>
        
        <div class="bg-gradient-to-r from-green-900 to-green-800 rounded-xl p-6">
            <div class="flex items-center justify-between">
                <div>
                    <div class="text-3xl font-bold"><?php echo $stats['tours']; ?></div>
                    <div class="text-green-200 text-sm mt-1">Total Tours</div>
                </div>
                <div class="w-12 h-12 bg-green-700 rounded-lg flex items-center justify-center">
                    <i class="fas fa-map-marked-alt text-2xl"></i>
                </div>
            </div>
            <div class="mt-4 text-green-300 text-sm">
                <i class="fas fa-map mr-1"></i> Available packages
            </div>
        </div>
        
        <div class="bg-gradient-to-r from-purple-900 to-purple-800 rounded-xl p-6">
            <div class="flex items-center justify-between">
                <div>
                    <div class="text-3xl font-bold"><?php echo $stats['bookings']; ?></div>
                    <div class="text-purple-200 text-sm mt-1">Total Bookings</div>
                </div>
                <div class="w-12 h-12 bg-purple-700 rounded-lg flex items-center justify-center">
                    <i class="fas fa-calendar-check text-2xl"></i>
                </div>
            </div>
            <div class="mt-4 text-purple-300 text-sm">
                <i class="fas fa-calendar mr-1"></i> All bookings
            </div>
        </div>
        
        <div class="bg-gradient-to-r from-yellow-900 to-yellow-800 rounded-xl p-6">
            <div class="flex items-center justify-between">
                <div>
                    <div class="text-3xl font-bold">৳<?php echo number_format($stats['revenue']); ?></div>
                    <div class="text-yellow-200 text-sm mt-1">Total Revenue</div>
                </div>
                <div class="w-12 h-12 bg-yellow-700 rounded-lg flex items-center justify-center">
                    <i class="fas fa-money-bill-wave text-2xl"></i>
                </div>
            </div>
            <div class="mt-4 text-yellow-300 text-sm">
                <i class="fas fa-chart-line mr-1"></i> Confirmed bookings
            </div>
        </div>
    </div>
    
    <!-- Recent Bookings -->
    <div class="bg-gray-800 rounded-xl p-6">
        <h2 class="text-xl font-bold mb-6">Recent Bookings</h2>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="border-b border-gray-700">
                        <th class="text-left py-3 px-4">Booking ID</th>
                        <th class="text-left py-3 px-4">User</th>
                        <th class="text-left py-3 px-4">Tour</th>
                        <th class="text-left py-3 px-4">Amount</th>
                        <th class="text-left py-3 px-4">Status</th>
                        <th class="text-left py-3 px-4">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($booking = $recent_bookings->fetch_assoc()): 
                        $status_color = $booking['status'] === 'confirmed' ? 'bg-green-900 text-green-100' : 
                                       ($booking['status'] === 'cancelled' ? 'bg-red-900 text-red-100' : 'bg-yellow-900 text-yellow-100');
                    ?>
                    <tr class="border-b border-gray-700/50 hover:bg-gray-700/30">
                        <td class="py-3 px-4">#<?php echo str_pad($booking['id'], 6, '0', STR_PAD_LEFT); ?></td>
                        <td class="py-3 px-4"><?php echo htmlspecialchars($booking['username']); ?></td>
                        <td class="py-3 px-4"><?php echo htmlspecialchars(substr($booking['title'], 0, 30)); ?>...</td>
                        <td class="py-3 px-4">৳<?php echo number_format($booking['total_amount']); ?></td>
                        <td class="py-3 px-4">
                            <span class="<?php echo $status_color; ?> px-3 py-1 rounded-full text-xs">
                                <?php echo ucfirst($booking['status']); ?>
                            </span>
                        </td>
                        <td class="py-3 px-4"><?php echo date('d/m/Y', strtotime($booking['booking_date'])); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        
        <div class="mt-6 text-center">
            <a href="bookings.php" class="inline-flex items-center text-green-400 hover:text-green-300">
                View All Bookings
                <i class="fas fa-arrow-right ml-2"></i>
            </a>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-gray-800 rounded-xl p-6">
            <h3 class="font-bold mb-4">Add New Tour</h3>
            <p class="text-gray-400 text-sm mb-6">Create a new tour package for customers</p>
            <a href="tours.php?action=add" class="inline-block bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg">
                <i class="fas fa-plus mr-2"></i>Add Tour
            </a>
        </div>
        
        <div class="bg-gray-800 rounded-xl p-6">
            <h3 class="font-bold mb-4">Payment Settings</h3>
            <p class="text-gray-400 text-sm mb-6">Update Bkash, Nagad and Bank details</p>
            <a href="settings.php" class="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg">
                <i class="fas fa-cog mr-2"></i>Update Settings
            </a>
        </div>
        
        <div class="bg-gray-800 rounded-xl p-6">
            <h3 class="font-bold mb-4">User Management</h3>
            <p class="text-gray-400 text-sm mb-6">View and manage registered users</p>
            <a href="users.php" class="inline-block bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg">
                <i class="fas fa-users mr-2"></i>Manage Users
            </a>
        </div>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>