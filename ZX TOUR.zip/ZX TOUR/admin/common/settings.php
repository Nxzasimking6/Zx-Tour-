<?php
$page_title = "Settings";
require_once 'common/header.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bkash_number = sanitize($_POST['bkash_number']);
    $nagad_number = sanitize($_POST['nagad_number']);
    $bank_name = sanitize($_POST['bank_name']);
    $bank_account = sanitize($_POST['bank_account']);
    $contact_email = sanitize($_POST['contact_email']);
    $contact_phone = sanitize($_POST['contact_phone']);
    $app_name = sanitize($_POST['app_name']);
    
    // Check if settings exist
    $check_query = "SELECT COUNT(*) as count FROM settings";
    $check_result = $conn->query($check_query);
    $count = $check_result->fetch_assoc()['count'];
    
    if ($count > 0) {
        // Update existing settings
        $stmt = $conn->prepare("UPDATE settings SET 
                                bkash_number = ?, 
                                nagad_number = ?, 
                                bank_name = ?, 
                                bank_account = ?, 
                                contact_email = ?, 
                                contact_phone = ?, 
                                app_name = ? 
                                WHERE id = 1");
        $stmt->bind_param("sssssss", $bkash_number, $nagad_number, $bank_name, $bank_account, $contact_email, $contact_phone, $app_name);
    } else {
        // Insert new settings
        $stmt = $conn->prepare("INSERT INTO settings (bkash_number, nagad_number, bank_name, bank_account, contact_email, contact_phone, app_name) 
                                VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $bkash_number, $nagad_number, $bank_name, $bank_account, $contact_email, $contact_phone, $app_name);
    }
    
    if ($stmt->execute()) {
        $success = 'Settings updated successfully';
        // Refresh settings
        $settings_query = "SELECT * FROM settings LIMIT 1";
        $settings_result = $conn->query($settings_query);
        $settings = $settings_result->fetch_assoc();
    } else {
        $error = 'Failed to update settings';
    }
    $stmt->close();
}

// Get current settings
$settings_query = "SELECT * FROM settings LIMIT 1";
$settings_result = $conn->query($settings_query);
$settings = $settings_result->fetch_assoc() ?? [];
?>

<div class="space-y-6">
    <?php if ($success): ?>
    <div class="bg-green-900/50 border border-green-700 text-green-100 px-4 py-3 rounded-lg">
        <i class="fas fa-check-circle mr-2"></i>
        <?php echo $success; ?>
    </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
    <div class="bg-red-900/50 border border-red-700 text-red-100 px-4 py-3 rounded-lg">
        <i class="fas fa-exclamation-circle mr-2"></i>
        <?php echo $error; ?>
    </div>
    <?php endif; ?>
    
    <!-- Settings Form -->
    <div class="bg-gray-800 rounded-xl p-6">
        <h2 class="text-xl font-bold mb-6">Payment & Contact Settings</h2>
        
        <form method="POST">
            <div class="space-y-8">
                <!-- Payment Methods -->
                <div>
                    <h3 class="text-lg font-bold mb-4 text-green-400"><i class="fas fa-credit-card mr-2"></i>Payment Methods</h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="bg-gray-700/50 p-5 rounded-lg">
                            <div class="flex items-center mb-4">
                                <div class="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center mr-3">
                                    <i class="fas fa-mobile-alt text-white"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold">Bkash Number</h4>
                                    <p class="text-gray-400 text-sm">Bangladesh's leading MFS</p>
                                </div>
                            </div>
                            <input type="text" name="bkash_number" required 
                                   value="<?php echo $settings['bkash_number'] ?? '017XXXXXXXX'; ?>"
                                   class="w-full bg-gray-600 border border-gray-500 rounded-lg px-4 py-3"
                                   placeholder="Enter Bkash number">
                        </div>
                        
                        <div class="bg-gray-700/50 p-5 rounded-lg">
                            <div class="flex items-center mb-4">
                                <div class="w-10 h-10 bg-green-700 rounded-lg flex items-center justify-center mr-3">
                                    <i class="fas fa-wallet text-white"></i>
                                </div>
                                <div>
                                    <h4 class="font-bold">Nagad Number</h4>
                                    <p class="text-gray-400 text-sm">Digital financial service</p>
                                </div>
                            </div>
                            <input type="text" name="nagad_number" required 
                                   value="<?php echo $settings['nagad_number'] ?? '017XXXXXXXX'; ?>"
                                   class="w-full bg-gray-600 border border-gray-500 rounded-lg px-4 py-3"
                                   placeholder="Enter Nagad number">
                        </div>
                    </div>
                    
                    <div class="mt-6 bg-gray-700/50 p-5 rounded-lg">
                        <div class="flex items-center mb-4">
                            <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                                <i class="fas fa-university text-white"></i>
                            </div>
                            <div>
                                <h4 class="font-bold">Bank Transfer Details</h4>
                                <p class="text-gray-400 text-sm">Bangladesh banking information</p>
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium mb-2">Bank Name</label>
                                <input type="text" name="bank_name" required 
                                       value="<?php echo $settings['bank_name'] ?? 'Bangladesh Bank'; ?>"
                                       class="w-full bg-gray-600 border border-gray-500 rounded-lg px-4 py-3">
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium mb-2">Account Number</label>
                                <input type="text" name="bank_account" required 
                                       value="<?php echo $settings['bank_account'] ?? '1234567890'; ?>"
                                       class="w-full bg-gray-600 border border-gray-500 rounded-lg px-4 py-3">
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Contact Information -->
                <div>
                    <h3 class="text-lg font-bold mb-4 text-blue-400"><i class="fas fa-headset mr-2"></i>Contact Information</h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="bg-gray-700/50 p-5 rounded-lg">
                            <label class="block text-sm font-medium mb-2">Contact Email</label>
                            <input type="email" name="contact_email" required 
                                   value="<?php echo $settings['contact_email'] ?? 'contact@zxtourff.com'; ?>"
                                   class="w-full bg-gray-600 border border-gray-500 rounded-lg px-4 py-3">
                        </div>
                        
                        <div class="bg-gray-700/50 p-5 rounded-lg">
                            <label class="block text-sm font-medium mb-2">Contact Phone</label>
                            <input type="text" name="contact_phone" required 
                                   value="<?php echo $settings['contact_phone'] ?? '017XXXXXXXX'; ?>"
                                   class="w-full bg-gray-600 border border-gray-500 rounded-lg px-4 py-3">
                        </div>
                    </div>
                </div>
                
                <!-- General Settings -->
                <div>
                    <h3 class="text-lg font-bold mb-4 text-purple-400"><i class="fas fa-cog mr-2"></i>General Settings</h3>
                    
                    <div class="bg-gray-700/50 p-5 rounded-lg">
                        <label class="block text-sm font-medium mb-2">Application Name</label>
                        <input type="text" name="app_name" required 
                               value="<?php echo $settings['app_name'] ?? 'Zx Tour FF'; ?>"
                               class="w-full bg-gray-600 border border-gray-500 rounded-lg px-4 py-3">
                    </div>
                </div>
                
                <div class="pt-6 border-t border-gray-700">
                    <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-lg transition duration-300">
                        <i class="fas fa-save mr-2"></i>Save All Settings
                    </button>
                </div>
            </div>
        </form>
    </div>
    
    <!-- Current Settings Preview -->
    <div class="bg-gray-800 rounded-xl p-6">
        <h2 class="text-xl font-bold mb-6">Current Settings Preview</h2>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-gray-700/30 p-5 rounded-lg border border-gray-700">
                <h4 class="font-bold mb-3 text-green-300">Bkash</h4>
                <div class="text-2xl font-bold mb-2"><?php echo $settings['bkash_number'] ?? '017XXXXXXXX'; ?></div>
                <p class="text-gray-400 text-sm">Customers can pay via Bkash to this number</p>
            </div>
            
            <div class="bg-gray-700/30 p-5 rounded-lg border border-gray-700">
                <h4 class="font-bold mb-3 text-green-300">Nagad</h4>
                <div class="text-2xl font-bold mb-2"><?php echo $settings['nagad_number'] ?? '017XXXXXXXX'; ?></div>
                <p class="text-gray-400 text-sm">Customers can pay via Nagad to this number</p>
            </div>
            
            <div class="bg-gray-700/30 p-5 rounded-lg border border-gray-700">
                <h4 class="font-bold mb-3 text-blue-300">Bank Details</h4>
                <div class="font-bold mb-1"><?php echo $settings['bank_name'] ?? 'Bangladesh Bank'; ?></div>
                <div class="text-lg mb-2">Account: <?php echo $settings['bank_account'] ?? '1234567890'; ?></div>
                <p class="text-gray-400 text-sm">Customers can transfer to this account</p>
            </div>
        </div>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>