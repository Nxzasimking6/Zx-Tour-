<?php
if (!isset($conn)) {
    require_once 'config.php';
}
requireAdminLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Admin Panel - <?php echo $page_title ?? 'Dashboard'; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
            -webkit-tap-highlight-color: transparent;
        }
        input, textarea, select {
            user-select: text;
        }
        .sidebar {
            width: 250px;
            transition: all 0.3s;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 0;
                overflow: hidden;
            }
            .sidebar.active {
                width: 250px;
            }
        }
    </style>
</head>
<body class="bg-gray-900 text-gray-100">
    <!-- Sidebar -->
    <div class="sidebar fixed top-0 left-0 h-full bg-gray-800 border-r border-gray-700 z-40">
        <div class="p-6 border-b border-gray-700">
            <a href="index.php" class="flex items-center space-x-2">
                <div class="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg flex items-center justify-center">
                    <i class="fas fa-crown text-white"></i>
                </div>
                <div>
                    <span class="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">
                        Admin Panel
                    </span>
                    <div class="text-xs text-gray-400">Zx Tour FF</div>
                </div>
            </a>
        </div>
        
        <div class="p-4">
            <div class="text-xs text-gray-500 uppercase tracking-wider mb-2 px-3">Main Menu</div>
            <nav class="space-y-1">
                <a href="index.php" class="flex items-center px-3 py-3 rounded-lg <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'bg-gray-700 text-green-400' : 'hover:bg-gray-700'; ?>">
                    <i class="fas fa-tachometer-alt w-6 mr-3"></i>
                    <span>Dashboard</span>
                </a>
                
                <a href="users.php" class="flex items-center px-3 py-3 rounded-lg <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'bg-gray-700 text-green-400' : 'hover:bg-gray-700'; ?>">
                    <i class="fas fa-users w-6 mr-3"></i>
                    <span>Users</span>
                </a>
                
                <a href="tours.php" class="flex items-center px-3 py-3 rounded-lg <?php echo basename($_SERVER['PHP_SELF']) == 'tours.php' ? 'bg-gray-700 text-green-400' : 'hover:bg-gray-700'; ?>">
                    <i class="fas fa-map-marked-alt w-6 mr-3"></i>
                    <span>Tours</span>
                </a>
                
                <a href="bookings.php" class="flex items-center px-3 py-3 rounded-lg <?php echo basename($_SERVER['PHP_SELF']) == 'bookings.php' ? 'bg-gray-700 text-green-400' : 'hover:bg-gray-700'; ?>">
                    <i class="fas fa-calendar-check w-6 mr-3"></i>
                    <span>Bookings</span>
                </a>
                
                <a href="payments.php" class="flex items-center px-3 py-3 rounded-lg <?php echo basename($_SERVER['PHP_SELF']) == 'payments.php' ? 'bg-gray-700 text-green-400' : 'hover:bg-gray-700'; ?>">
                    <i class="fas fa-credit-card w-6 mr-3"></i>
                    <span>Payments</span>
                </a>
                
                <a href="settings.php" class="flex items-center px-3 py-3 rounded-lg <?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'bg-gray-700 text-green-400' : 'hover:bg-gray-700'; ?>">
                    <i class="fas fa-cog w-6 mr-3"></i>
                    <span>Settings</span>
                </a>
            </nav>
            
            <div class="mt-8 pt-6 border-t border-gray-700">
                <a href="../index.php" target="_blank" class="flex items-center px-3 py-3 rounded-lg hover:bg-gray-700">
                    <i class="fas fa-external-link-alt w-6 mr-3"></i>
                    <span>View Website</span>
                </a>
                
                <a href="logout.php" class="flex items-center px-3 py-3 rounded-lg hover:bg-red-900/30 text-red-400">
                    <i class="fas fa-sign-out-alt w-6 mr-3"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="ml-0 md:ml-[250px] min-h-screen">
        <!-- Top Bar -->
        <header class="bg-gray-800 border-b border-gray-700 sticky top-0 z-30">
            <div class="flex items-center justify-between px-6 py-4">
                <div class="flex items-center">
                    <button id="menuToggle" class="md:hidden text-gray-400 hover:text-white mr-4">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-xl font-bold"><?php echo $page_title ?? 'Dashboard'; ?></h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <div class="text-sm text-gray-400">
                        <i class="fas fa-user-shield mr-2"></i>
                        <?php echo $_SESSION['admin_username']; ?>
                    </div>
                    <div class="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                        <i class="fas fa-user text-sm"></i>
                    </div>
                </div>
            </div>
        </header>
        
        <!-- Content -->
        <main class="p-6">