    </main>
    
    <!-- Bottom Navigation -->
    <nav class="glass-effect fixed bottom-0 left-0 right-0 border-t border-gray-700">
        <div class="container mx-auto">
            <div class="flex justify-around items-center h-16">
                <a href="index.php" class="flex flex-col items-center <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'text-green-400' : 'text-gray-400'; ?>">
                    <i class="fas fa-home text-lg mb-1"></i>
                    <span class="text-xs">Home</span>
                </a>
                
                <a href="tours.php" class="flex flex-col items-center <?php echo basename($_SERVER['PHP_SELF']) == 'tours.php' ? 'text-green-400' : 'text-gray-400'; ?>">
                    <i class="fas fa-map-marked-alt text-lg mb-1"></i>
                    <span class="text-xs">Tours</span>
                </a>
                
                <a href="my-bookings.php" class="flex flex-col items-center <?php echo basename($_SERVER['PHP_SELF']) == 'my-bookings.php' ? 'text-green-400' : 'text-gray-400'; ?>">
                    <i class="fas fa-calendar-check text-lg mb-1"></i>
                    <span class="text-xs">Bookings</span>
                </a>
                
                <?php if (isLoggedIn()): ?>
                <a href="profile.php" class="flex flex-col items-center <?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'text-green-400' : 'text-gray-400'; ?>">
                    <i class="fas fa-user text-lg mb-1"></i>
                    <span class="text-xs">Profile</span>
                </a>
                <?php else: ?>
                <a href="login.php" class="flex flex-col items-center <?php echo basename($_SERVER['PHP_SELF']) == 'login.php' ? 'text-green-400' : 'text-gray-400'; ?>">
                    <i class="fas fa-sign-in-alt text-lg mb-1"></i>
                    <span class="text-xs">Login</span>
                </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    
    <script>
        // Disable right-click
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
            return false;
        });
        
        // Disable zoom with Ctrl + Scroll
        document.addEventListener('wheel', function(e) {
            if (e.ctrlKey) {
                e.preventDefault();
            }
        }, { passive: false });
        
        // Disable keyboard zoom (Ctrl + +, Ctrl + -, Ctrl + 0)
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && (e.key === '+' || e.key === '-' || e.key === '0' || e.keyCode === 187 || e.keyCode === 189 || e.keyCode === 48)) {
                e.preventDefault();
            }
        });
        
        // Disable text selection except inputs
        document.addEventListener('selectstart', function(e) {
            if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
                e.preventDefault();
            }
        });
        
        // Auto-hide address bar on mobile
        window.addEventListener('load', function() {
            setTimeout(function() {
                window.scrollTo(0, 1);
            }, 0);
        });
    </script>
</body>
</html>