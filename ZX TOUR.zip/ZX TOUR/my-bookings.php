<?php
$page_title = "My Bookings";
require_once 'common/config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

// Handle booking cancellation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_booking'])) {
    $booking_id = intval($_POST['booking_id']);
    $stmt = $conn->prepare("UPDATE bookings SET status = 'cancelled' WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $booking_id, $_SESSION['user_id']);
    $stmt->execute();
    $stmt->close();
}

// Check for payment success message
$payment_success = false;
if (isset($_SESSION['payment_success'])) {
    $payment_success = true;
    unset($_SESSION['payment_success']);
}

// Fetch user bookings
$user_id = $_SESSION['user_id'];
$bookings_query = $conn->prepare("SELECT b.*, t.title, t.destination, p.status as payment_status 
                                  FROM bookings b
                                  JOIN tours t ON b.tour_id = t.id
                                  LEFT JOIN payments p ON b.id = p.booking_id
                                  WHERE b.user_id = ?
                                  ORDER BY b.created_at DESC");
$bookings_query->bind_param("i", $user_id);
$bookings_query->execute();
$bookings_result = $bookings_query->get_result();

require_once 'common/header.php';
?>

<div class="container mx-auto px-4 py-6">
    <h1 class="text-3xl font-bold mb-2">My Bookings</h1>
    <p class="text-gray-400 mb-8">View and manage your tour bookings</p>
    
    <?php if ($payment_success): ?>
    <div class="bg-green-900/50 border border-green-700 text-green-100 px-4 py-3 rounded-lg mb-6">
        <i class="fas fa-check-circle mr-2"></i>
        Payment submitted successfully! Your booking is being processed.
    </div>
    <?php endif; ?>
    
    <?php if ($bookings_result->num_rows === 0): ?>
    <div class="bg-gray-800 rounded-xl p-12 text-center">
        <div class="w-20 h-20 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-6">
            <i class="fas fa-calendar-times text-3xl text-gray-500"></i>
        </div>
        <h3 class="text-xl font-bold mb-3">No Bookings Yet</h3>
        <p class="text-gray-400 mb-6">You haven't made any tour bookings yet.</p>
        <a href="tours.php" class="inline-block bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium">
            <i class="fas fa-map-marked-alt mr-2"></i>Browse Tours
        </a>
    </div>
    <?php else: ?>
    <div class="space-y-6">
        <?php while($booking = $bookings_result->fetch_assoc()): 
            $status_color = $booking['status'] === 'confirmed' ? 'bg-green-900 text-green-100' : 
                           ($booking['status'] === 'cancelled' ? 'bg-red-900 text-red-100' : 'bg-yellow-900 text-yellow-100');
            
            $payment_color = $booking['payment_status'] === 'completed' ? 'bg-green-900 text-green-100' : 
                            ($booking['payment_status'] === 'failed' ? 'bg-red-900 text-red-100' : 'bg-yellow-900 text-yellow-100');
        ?>
        <div class="bg-gray-800 rounded-xl overflow-hidden border border-gray-700">
            <div class="p-6">
                <div class="flex flex-col md:flex-row md:items-center justify-between mb-6">
                    <div>
                        <h3 class="text-xl font-bold mb-2"><?php echo htmlspecialchars($booking['title']); ?></h3>
                        <div class="flex items-center text-gray-400">
                            <i class="fas fa-map-marker-alt mr-2"></i>
                            <span><?php echo htmlspecialchars($booking['destination']); ?></span>
                            <span class="mx-3">•</span>
                            <i class="fas fa-calendar-day mr-2"></i>
                            <span><?php echo date('d M Y', strtotime($booking['booking_date'])); ?></span>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4 mt-4 md:mt-0">
                        <span class="<?php echo $status_color; ?> px-3 py-1 rounded-full text-sm">
                            <?php echo ucfirst($booking['status']); ?>
                        </span>
                        <span class="<?php echo $payment_color; ?> px-3 py-1 rounded-full text-sm">
                            <?php echo ucfirst($booking['payment_status'] ?? 'pending'); ?>
                        </span>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div class="bg-gray-700/50 p-4 rounded-lg">
                        <div class="text-sm text-gray-400 mb-1">Booking ID</div>
                        <div class="font-bold">#<?php echo str_pad($booking['id'], 6, '0', STR_PAD_LEFT); ?></div>
                    </div>
                    <div class="bg-gray-700/50 p-4 rounded-lg">
                        <div class="text-sm text-gray-400 mb-1">Persons</div>
                        <div class="font-bold"><?php echo $booking['persons']; ?> Person<?php echo $booking['persons'] > 1 ? 's' : ''; ?></div>
                    </div>
                    <div class="bg-gray-700/50 p-4 rounded-lg">
                        <div class="text-sm text-gray-400 mb-1">Total Amount</div>
                        <div class="text-xl font-bold text-green-400">৳<?php echo number_format($booking['total_amount']); ?></div>
                    </div>
                </div>
                
                <div class="flex flex-col sm:flex-row gap-3">
                    <?php if ($booking['status'] === 'pending'): ?>
                    <a href="payment.php?booking_id=<?php echo $booking['id']; ?>" 
                       class="flex-1 bg-green-600 hover:bg-green-700 text-white text-center py-3 rounded-lg">
                        <i class="fas fa-credit-card mr-2"></i>Complete Payment
                    </a>
                    <form method="POST" class="flex-1">
                        <input type="hidden" name="booking_id" value="<?php echo $booking['id']; ?>">
                        <button type="submit" name="cancel_booking" 
                                class="w-full bg-red-600 hover:bg-red-700 text-white py-3 rounded-lg"
                                onclick="return confirm('Are you sure you want to cancel this booking?')">
                            <i class="fas fa-times-circle mr-2"></i>Cancel Booking
                        </button>
                    </form>
                    <?php elseif ($booking['status'] === 'confirmed'): ?>
                    <div class="flex-1 bg-blue-600 text-white text-center py-3 rounded-lg">
                        <i class="fas fa-check-circle mr-2"></i>Confirmed
                    </div>
                    <a href="#" class="flex-1 bg-gray-700 hover:bg-gray-600 text-white text-center py-3 rounded-lg">
                        <i class="fas fa-download mr-2"></i>Download Ticket
                    </a>
                    <?php else: ?>
                    <div class="flex-1 bg-gray-700 text-white text-center py-3 rounded-lg">
                        <i class="fas fa-ban mr-2"></i>Cancelled
                    </div>
                    <a href="tours.php" class="flex-1 bg-green-600 hover:bg-green-700 text-white text-center py-3 rounded-lg">
                        <i class="fas fa-redo mr-2"></i>Book Again
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>
</div>

<?php require_once 'common/bottom.php'; ?>