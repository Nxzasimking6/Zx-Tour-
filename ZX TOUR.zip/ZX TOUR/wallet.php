<?php require 'common/config.php'; include 'common/header.php'; ?>

<div class="bg-gradient-to-br from-gray-800 to-gray-700 p-6 rounded-2xl mb-6 shadow-xl">
    <p class="text-gray-400">Available Balance</p>
    <h2 class="text-4xl font-black mt-1">৳<?php echo $user['wallet']; ?></h2>
</div>

<h3 class="mb-4 font-bold text-gray-300">Add Money (Manual)</h3>
<div class="grid grid-cols-2 gap-4">
    <button class="bg-pink-600 p-4 rounded-xl flex flex-col items-center justify-center space-y-2 border-2 border-transparent active:border-white">
        <span class="font-bold">bKash</span>
    </button>
    <button class="bg-orange-600 p-4 rounded-xl flex flex-col items-center justify-center space-y-2 border-2 border-transparent active:border-white">
        <span class="font-bold">Nagad</span>
    </button>
</div>

<form action="process_deposit.php" method="POST" class="mt-6 space-y-4">
    <input type="number" name="amount" placeholder="Enter Amount" class="w-full bg-gray-800 border border-gray-600 p-3 rounded-lg focus:outline-none">
    <input type="text" name="trxid" placeholder="Transaction ID" class="w-full bg-gray-800 border border-gray-600 p-3 rounded-lg focus:outline-none">
    <button class="w-full bg-green-600 py-3 rounded-lg font-bold">Submit Payment</button>
</form>

<?php include 'common/bottom.php'; ?>