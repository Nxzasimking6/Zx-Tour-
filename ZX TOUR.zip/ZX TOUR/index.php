<?php
$page_title = "Home";
require_once 'common/header.php';

// Fetch featured tours
$featured_query = "SELECT * FROM tours WHERE is_featured = 1 ORDER BY id DESC LIMIT 3";
$featured_result = $conn->query($featured_query);
?>

<div class="container mx-auto px-4 py-6">
    <!-- Hero Banner -->
    <div class="relative rounded-2xl overflow-hidden mb-8">
        <div class="h-64 md:h-80 bg-gradient-to-r from-green-900 to-blue-900 flex items-center justify-center">
            <div class="text-center px-4">
                <h1 class="text-3xl md:text-4xl font-bold mb-3">Explore Bangladesh With <span class="text-green-400">Zx Tour FF</span></h1>
                <p class="text-gray-300 mb-6">Book amazing tours with Bangladesh's trusted payment methods</p>
                <a href="tours.php" class="inline-block bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-8 rounded-full transition duration-300">
                    Book Now
                </a>
            </div>
        </div>
    </div>
    
    <!-- Payment Methods -->
    <div class="mb-10">
        <h2 class="text-2xl font-bold mb-6 flex items-center">
            <i class="fas fa-credit-card mr-3 text-green-400"></i>
            Payment Methods
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center mr-4">
                        <i class="fas fa-mobile-alt text-white text-xl"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-lg">Bkash</h3>
                        <p class="text-gray-400 text-sm">Bangladesh's Leading Mobile Financial Service</p>
                    </div>
                </div>
                <p class="text-gray-300">Send money to our Bkash number for quick and secure payments.</p>
            </div>
            
            <div class="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-green-700 rounded-lg flex items-center justify-center mr-4">
                        <i class="fas fa-wallet text-white text-xl"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-lg">Nagad</h3>
                        <p class="text-gray-400 text-sm">Digital Financial Service by Bangladesh Post Office</p>
                    </div>
                </div>
                <p class="text-gray-300">Use Nagad for fast and reliable payment transactions.</p>
            </div>
            
            <div class="bg-gray-800 rounded-xl p-6 border border-gray-700">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
                        <i class="fas fa-university text-white text-xl"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-lg">Bank Transfer</h3>
                        <p class="text-gray-400 text-sm">Direct Bank Transfer</p>
                    </div>
                </div>
                <p class="text-gray-300">Transfer directly to our Bangladesh bank account.</p>
            </div>
        </div>
    </div>
    
    <!-- Featured Tours -->
    <div class="mb-10">
        <h2 class="text-2xl font-bold mb-6 flex items-center">
            <i class="fas fa-star mr-3 text-yellow-400"></i>
            Featured Tours
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php while($tour = $featured_result->fetch_assoc()): ?>
            <div class="bg-gray-800 rounded-xl overflow-hidden border border-gray-700 hover:border-green-500 transition duration-300">
                <div class="h-48 bg-gray-700 flex items-center justify-center">
                    <i class="fas fa-mountain text-4xl text-gray-600"></i>
                </div>
                <div class="p-5">
                    <div class="flex justify-between items-start mb-3">
                        <h3 class="font-bold text-lg"><?php echo htmlspecialchars($tour['title']); ?></h3>
                        <span class="bg-green-900 text-green-100 text-sm px-3 py-1 rounded-full">
                            <?php echo $tour['available_seats']; ?> seats
                        </span>
                    </div>
                    <p class="text-gray-400 text-sm mb-4"><?php echo htmlspecialchars(substr($tour['description'], 0, 80)); ?>...</p>
                    <div class="flex justify-between items-center">
                        <div>
                            <span class="text-2xl font-bold text-green-400">৳<?php echo number_format($tour['discount_price']); ?></span>
                            <?php if($tour['price'] > $tour['discount_price']): ?>
                            <span class="text-gray-500 line-through ml-2">৳<?php echo number_format($tour['price']); ?></span>
                            <?php endif; ?>
                        </div>
                        <a href="tours.php?tour=<?php echo $tour['id']; ?>" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm">
                            View Details
                        </a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    </div>
    
    <!-- How It Works -->
    <div class="bg-gray-800 rounded-xl p-8 mb-10">
        <h2 class="text-2xl font-bold mb-8 text-center">How It Works</h2>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div class="text-center">
                <div class="w-16 h-16 bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span class="text-2xl font-bold">1</span>
                </div>
                <h3 class="font-bold mb-2">Choose Tour</h3>
                <p class="text-gray-400 text-sm">Select your preferred tour package</p>
            </div>
            <div class="text-center">
                <div class="w-16 h-16 bg-blue-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span class="text-2xl font-bold">2</span>
                </div>
                <h3 class="font-bold mb-2">Book & Pay</h3>
                <p class="text-gray-400 text-sm">Book and pay via Bkash/Nagad/Bank</p>
            </div>
            <div class="text-center">
                <div class="w-16 h-16 bg-purple-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span class="text-2xl font-bold">3</span>
                </div>
                <h3 class="font-bold mb-2">Get Confirmation</h3>
                <p class="text-gray-400 text-sm">Receive booking confirmation</p>
            </div>
            <div class="text-center">
                <div class="w-16 h-16 bg-yellow-900 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span class="text-2xl font-bold">4</span>
                </div>
                <h3 class="font-bold mb-2">Enjoy Tour</h3>
                <p class="text-gray-400 text-sm">Enjoy your amazing travel experience</p>
            </div>
        </div>
    </div>
</div>

<?php require_once 'common/bottom.php'; ?>