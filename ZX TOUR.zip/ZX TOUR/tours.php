<?php
$page_title = "Tours";
require_once 'common/header.php';

// Get tour details if ID is provided
$tour_detail = null;
if (isset($_GET['tour'])) {
    $tour_id = intval($_GET['tour']);
    $stmt = $conn->prepare("SELECT * FROM tours WHERE id = ?");
    $stmt->bind_param("i", $tour_id);
    $stmt->execute();
    $tour_detail = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Handle booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_tour'])) {
    if (!isLoggedIn()) {
        redirect('login.php');
    }
    
    $tour_id = intval($_POST['tour_id']);
    $persons = intval($_POST['persons']);
    $booking_date = sanitize($_POST['booking_date']);
    
    // Get tour price
    $tour_query = $conn->prepare("SELECT discount_price FROM tours WHERE id = ?");
    $tour_query->bind_param("i", $tour_id);
    $tour_query->execute();
    $tour_result = $tour_query->get_result();
    $tour = $tour_result->fetch_assoc();
    $total_amount = $tour['discount_price'] * $persons;
    
    // Insert booking
    $stmt = $conn->prepare("INSERT INTO bookings (user_id, tour_id, booking_date, persons, total_amount) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisid", $_SESSION['user_id'], $tour_id, $booking_date, $persons, $total_amount);
    
    if ($stmt->execute()) {
        $booking_id = $stmt->insert_id;
        $stmt->close();
        
        // Redirect to payment page
        header("Location: payment.php?booking_id=$booking_id");
        exit();
    }
    $stmt->close();
}

// Fetch all tours
$tours_query = "SELECT * FROM tours ORDER BY created_at DESC";
$tours_result = $conn->query($tours_query);
?>

<div class="container mx-auto px-4 py-6">
    <?php if ($tour_detail): ?>
    <!-- Tour Detail View -->
    <div class="max-w-4xl mx-auto">
        <a href="tours.php" class="inline-flex items-center text-green-400 mb-6">
            <i class="fas fa-arrow-left mr-2"></i> Back to Tours
        </a>
        
        <div class="bg-gray-800 rounded-2xl overflow-hidden">
            <div class="h-64 bg-gradient-to-r from-green-900 to-blue-900 flex items-center justify-center">
                <i class="fas fa-mountain text-6xl text-gray-300"></i>
            </div>
            
            <div class="p-6 md:p-8">
                <div class="flex flex-col md:flex-row justify-between items-start mb-6">
                    <div>
                        <h1 class="text-3xl font-bold mb-2"><?php echo htmlspecialchars($tour_detail['title']); ?></h1>
                        <div class="flex items-center text-gray-400 mb-4">
                            <i class="fas fa-map-marker-alt mr-2"></i>
                            <span><?php echo htmlspecialchars($tour_detail['destination']); ?></span>
                            <span class="mx-3">•</span>
                            <i class="fas fa-clock mr-2"></i>
                            <span><?php echo htmlspecialchars($tour_detail['duration']); ?></span>
                        </div>
                    </div>
                    <div class="bg-green-900/50 border border-green-700 px-6 py-3 rounded-xl">
                        <div class="text-3xl font-bold text-green-400">৳<?php echo number_format($tour_detail['discount_price']); ?></div>
                        <?php if($tour_detail['price'] > $tour_detail['discount_price']): ?>
                        <div class="text-gray-400 line-through text-center">৳<?php echo number_format($tour_detail['price']); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="mb-8">
                    <h2 class="text-xl font-bold mb-4">Description</h2>
                    <p class="text-gray-300 leading-relaxed"><?php echo nl2br(htmlspecialchars($tour_detail['description'])); ?></p>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="bg-gray-700/50 p-4 rounded-xl">
                        <div class="flex items-center mb-2">
                            <div class="w-10 h-10 bg-blue-900 rounded-lg flex items-center justify-center mr-3">
                                <i class="fas fa-users text-blue-300"></i>
                            </div>
                            <div>
                                <div class="font-bold text-lg"><?php echo $tour_detail['available_seats']; ?></div>
                                <div class="text-gray-400 text-sm">Available Seats</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-gray-700/50 p-4 rounded-xl">
                        <div class="flex items-center mb-2">
                            <div class="w-10 h-10 bg-green-900 rounded-lg flex items-center justify-center mr-3">
                                <i class="fas fa-calendar-alt text-green-300"></i>
                            </div>
                            <div>
                                <div class="font-bold text-lg"><?php echo $tour_detail['duration']; ?></div>
                                <div class="text-gray-400 text-sm">Duration</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-gray-700/50 p-4 rounded-xl">
                        <div class="flex items-center mb-2">
                            <div class="w-10 h-10 bg-purple-900 rounded-lg flex items-center justify-center mr-3">
                                <i class="fas fa-map-marked-alt text-purple-300"></i>
                            </div>
                            <div>
                                <div class="font-bold text-lg"><?php echo htmlspecialchars($tour_detail['destination']); ?></div>
                                <div class="text-gray-400 text-sm">Destination</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if (isLoggedIn()): ?>
                <div class="bg-gray-700/50 p-6 rounded-xl">
                    <h2 class="text-xl font-bold mb-4">Book This Tour</h2>
                    <form method="POST">
                        <input type="hidden" name="tour_id" value="<?php echo $tour_detail['id']; ?>">
                        <input type="hidden" name="book_tour" value="1">
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <div>
                                <label class="block text-sm font-medium mb-2">Number of Persons</label>
                                <select name="persons" required class="w-full bg-gray-600 border border-gray-500 rounded-lg px-4 py-3">
                                    <?php for($i = 1; $i <= 10; $i++): ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?> Person<?php echo $i > 1 ? 's' : ''; ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium mb-2">Preferred Date</label>
                                <input type="date" name="booking_date" required 
                                       class="w-full bg-gray-600 border border-gray-500 rounded-lg px-4 py-3">
                            </div>
                        </div>
                        
                        <div class="bg-gray-800 p-4 rounded-lg mb-6">
                            <div class="flex justify-between items-center">
                                <span class="text-gray-400">Total Amount:</span>
                                <span class="text-2xl font-bold text-green-400">৳<span id="totalAmount"><?php echo number_format($tour_detail['discount_price']); ?></span></span>
                            </div>
                        </div>
                        
                        <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-4 px-6 rounded-lg text-lg transition duration-300">
                            <i class="fas fa-calendar-check mr-2"></i>Book Now
                        </button>
                    </form>
                </div>
                <?php else: ?>
                <div class="bg-blue-900/30 border border-blue-700 p-6 rounded-xl text-center">
                    <h3 class="text-xl font-bold mb-3">Login Required</h3>
                    <p class="text-gray-300 mb-4">Please login to book this tour</p>
                    <a href="login.php" class="inline-block bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-medium">
                        <i class="fas fa-sign-in-alt mr-2"></i>Login to Book
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
        // Calculate total amount based on persons
        document.querySelector('select[name="persons"]').addEventListener('change', function() {
            const price = <?php echo $tour_detail['discount_price']; ?>;
            const persons = this.value;
            const total = price * persons;
            document.getElementById('totalAmount').textContent = total.toLocaleString();
        });
    </script>
    
    <?php else: ?>
    <!-- Tours List View -->
    <h1 class="text-3xl font-bold mb-2">Available Tours</h1>
    <p class="text-gray-400 mb-8">Choose from our amazing tour packages</p>
    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php while($tour = $tours_result->fetch_assoc()): ?>
        <div class="bg-gray-800 rounded-xl overflow-hidden border border-gray-700 hover:border-green-500 transition duration-300">
            <div class="h-48 bg-gradient-to-r from-green-900 to-blue-900 flex items-center justify-center relative">
                <?php if($tour['is_featured']): ?>
                <div class="absolute top-4 left-4 bg-yellow-600 text-white px-3 py-1 rounded-full text-sm">
                    <i class="fas fa-star mr-1"></i> Featured
                </div>
                <?php endif; ?>
                <i class="fas fa-mountain text-5xl text-gray-300"></i>
            </div>
            
            <div class="p-5">
                <div class="flex justify-between items-start mb-3">
                    <h3 class="font-bold text-lg"><?php echo htmlspecialchars($tour['title']); ?></h3>
                    <span class="bg-green-900 text-green-100 text-xs px-2 py-1 rounded">
                        <?php echo $tour['available_seats']; ?> seats
                    </span>
                </div>
                
                <div class="flex items-center text-gray-400 text-sm mb-3">
                    <i class="fas fa-map-marker-alt mr-2"></i>
                    <span><?php echo htmlspecialchars($tour['destination']); ?></span>
                    <span class="mx-2">•</span>
                    <i class="fas fa-clock mr-2"></i>
                    <span><?php echo htmlspecialchars($tour['duration']); ?></span>
                </div>
                
                <p class="text-gray-400 text-sm mb-4"><?php echo htmlspecialchars(substr($tour['description'], 0, 100)); ?>...</p>
                
                <div class="flex justify-between items-center mb-4">
                    <div>
                        <span class="text-2xl font-bold text-green-400">৳<?php echo number_format($tour['discount_price']); ?></span>
                        <?php if($tour['price'] > $tour['discount_price']): ?>
                        <span class="text-gray-500 line-through ml-2">৳<?php echo number_format($tour['price']); ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="flex gap-2">
                    <a href="tours.php?tour=<?php echo $tour['id']; ?>" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-center py-2 rounded-lg">
                        View Details
                    </a>
                    <?php if (isLoggedIn()): ?>
                    <a href="tours.php?tour=<?php echo $tour['id']; ?>#book" class="flex-1 bg-green-600 hover:bg-green-700 text-white text-center py-2 rounded-lg">
                        Book Now
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>
</div>

<?php require_once 'common/bottom.php'; ?>