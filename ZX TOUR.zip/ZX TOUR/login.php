<?php
$page_title = "Login";
require_once 'common/config.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'login';
    
    if ($action === 'login') {
        $username = sanitize($_POST['username']);
        $password = $_POST['password'];
        
        $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                redirect('index.php');
            } else {
                $error = 'Invalid password';
            }
        } else {
            $error = 'User not found';
        }
        $stmt->close();
    } elseif ($action === 'signup') {
        $username = sanitize($_POST['username']);
        $email = sanitize($_POST['email']);
        $password = $_POST['password'];
        $confirm_password = $_POST['confirm_password'];
        
        // Validation
        if (empty($username) || empty($email) || empty($password)) {
            $error = 'All fields are required';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters';
        } else {
            // Check if username or email exists
            $check_stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $check_stmt->bind_param("ss", $username, $email);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                $error = 'Username or email already exists';
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $insert_stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
                $insert_stmt->bind_param("sss", $username, $email, $hashed_password);
                
                if ($insert_stmt->execute()) {
                    $success = 'Registration successful! Please login.';
                } else {
                    $error = 'Registration failed';
                }
                $insert_stmt->close();
            }
            $check_stmt->close();
        }
    }
}

require_once 'common/header.php';
?>

<div class="container mx-auto px-4 py-8 max-w-md">
    <div class="text-center mb-8">
        <h1 class="text-3xl font-bold mb-2">Welcome to <span class="text-green-400">Zx Tour FF</span></h1>
        <p class="text-gray-400">Login to book tours or create a new account</p>
    </div>
    
    <?php if ($error): ?>
    <div class="bg-red-900/50 border border-red-700 text-red-100 px-4 py-3 rounded-lg mb-6">
        <i class="fas fa-exclamation-circle mr-2"></i>
        <?php echo $error; ?>
    </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
    <div class="bg-green-900/50 border border-green-700 text-green-100 px-4 py-3 rounded-lg mb-6">
        <i class="fas fa-check-circle mr-2"></i>
        <?php echo $success; ?>
    </div>
    <?php endif; ?>
    
    <div class="bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <!-- Tabs -->
        <div class="flex border-b border-gray-700">
            <button id="loginTab" class="flex-1 py-4 text-center font-medium bg-gray-800 text-green-400 border-b-2 border-green-400">
                <i class="fas fa-sign-in-alt mr-2"></i>Login
            </button>
            <button id="signupTab" class="flex-1 py-4 text-center font-medium text-gray-400 hover:text-gray-300">
                <i class="fas fa-user-plus mr-2"></i>Sign Up
            </button>
        </div>
        
        <!-- Login Form -->
        <div id="loginForm" class="p-6">
            <form method="POST">
                <input type="hidden" name="action" value="login">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">Username or Email</label>
                    <input type="text" name="username" required 
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
                
                <div class="mb-6">
                    <label class="block text-sm font-medium mb-2">Password</label>
                    <input type="password" name="password" required 
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
                
                <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                    <i class="fas fa-sign-in-alt mr-2"></i>Login
                </button>
            </form>
        </div>
        
        <!-- Signup Form -->
        <div id="signupForm" class="p-6 hidden">
            <form method="POST">
                <input type="hidden" name="action" value="signup">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">Username</label>
                    <input type="text" name="username" required 
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">Email</label>
                    <input type="email" name="email" required 
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">Password</label>
                    <input type="password" name="password" required 
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
                
                <div class="mb-6">
                    <label class="block text-sm font-medium mb-2">Confirm Password</label>
                    <input type="password" name="confirm_password" required 
                           class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500">
                </div>
                
                <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                    <i class="fas fa-user-plus mr-2"></i>Create Account
                </button>
            </form>
        </div>
    </div>
    
    <div class="text-center mt-6 text-gray-400">
        <p>By continuing, you agree to our <a href="#" class="text-green-400 hover:underline">Terms & Conditions</a></p>
    </div>
</div>

<script>
    // Tab switching
    document.getElementById('loginTab').addEventListener('click', function() {
        document.getElementById('loginTab').classList.add('bg-gray-800', 'text-green-400', 'border-b-2', 'border-green-400');
        document.getElementById('signupTab').classList.remove('bg-gray-800', 'text-green-400', 'border-b-2', 'border-green-400');
        document.getElementById('signupTab').classList.add('text-gray-400');
        document.getElementById('loginForm').classList.remove('hidden');
        document.getElementById('signupForm').classList.add('hidden');
    });
    
    document.getElementById('signupTab').addEventListener('click', function() {
        document.getElementById('signupTab').classList.add('bg-gray-800', 'text-green-400', 'border-b-2', 'border-green-400');
        document.getElementById('loginTab').classList.remove('bg-gray-800', 'text-green-400', 'border-b-2', 'border-green-400');
        document.getElementById('loginTab').classList.add('text-gray-400');
        document.getElementById('signupForm').classList.remove('hidden');
        document.getElementById('loginForm').classList.add('hidden');
    });
</script>

<?php require_once 'common/bottom.php'; ?>