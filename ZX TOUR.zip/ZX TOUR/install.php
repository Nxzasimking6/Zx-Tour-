<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Zx Tour FF</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>
</head>
<body class="bg-gray-900 text-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-8 max-w-4xl">
        <div class="text-center mb-10">
            <h1 class="text-4xl font-bold text-green-500 mb-2">Zx Tour FF</h1>
            <p class="text-gray-400">Installation Wizard</p>
        </div>

        <div class="bg-gray-800 rounded-xl shadow-2xl p-6 mb-8">
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $host = '127.0.0.1';
                $user = 'root';
                $pass = 'root';
                
                // Create connection
                $conn = new mysqli($host, $user, $pass);
                
                if ($conn->connect_error) {
                    die("<div class='bg-red-900 text-red-100 p-4 rounded mb-4'>
                        Connection failed: " . $conn->connect_error . "
                    </div>");
                }
                
                // Create database
                $sql = "CREATE DATABASE IF NOT EXISTS zx_tour_ff CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
                if ($conn->query($sql) === TRUE) {
                    echo "<div class='bg-green-900 text-green-100 p-4 rounded mb-4'>
                        Database created successfully
                    </div>";
                    
                    // Select database
                    $conn->select_db("zx_tour_ff");
                    
                    // Create users table
                    $sql = "CREATE TABLE IF NOT EXISTS users (
                        id INT(11) AUTO_INCREMENT PRIMARY KEY,
                        username VARCHAR(50) UNIQUE NOT NULL,
                        email VARCHAR(100) UNIQUE NOT NULL,
                        password VARCHAR(255) NOT NULL,
                        phone VARCHAR(20),
                        address TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                    )";
                    
                    if ($conn->query($sql) === TRUE) {
                        echo "<div class='bg-green-900 text-green-100 p-4 rounded mb-4'>
                            Users table created successfully
                        </div>";
                    }
                    
                    // Create admin table
                    $sql = "CREATE TABLE IF NOT EXISTS admin (
                        id INT(11) AUTO_INCREMENT PRIMARY KEY,
                        username VARCHAR(50) UNIQUE NOT NULL,
                        password VARCHAR(255) NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )";
                    
                    if ($conn->query($sql) === TRUE) {
                        echo "<div class='bg-green-900 text-green-100 p-4 rounded mb-4'>
                            Admin table created successfully
                        </div>";
                    }
                    
                    // Create tours table
                    $sql = "CREATE TABLE IF NOT EXISTS tours (
                        id INT(11) AUTO_INCREMENT PRIMARY KEY,
                        title VARCHAR(200) NOT NULL,
                        description TEXT,
                        destination VARCHAR(100),
                        duration VARCHAR(50),
                        price DECIMAL(10,2),
                        discount_price DECIMAL(10,2),
                        image_url VARCHAR(500),
                        available_seats INT(11),
                        is_featured BOOLEAN DEFAULT FALSE,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                    )";
                    
                    if ($conn->query($sql) === TRUE) {
                        echo "<div class='bg-green-900 text-green-100 p-4 rounded mb-4'>
                            Tours table created successfully
                        </div>";
                    }
                    
                    // Create bookings table
                    $sql = "CREATE TABLE IF NOT EXISTS bookings (
                        id INT(11) AUTO_INCREMENT PRIMARY KEY,
                        user_id INT(11),
                        tour_id INT(11),
                        booking_date DATE,
                        persons INT(11),
                        total_amount DECIMAL(10,2),
                        status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
                        payment_method VARCHAR(50),
                        transaction_id VARCHAR(100),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id),
                        FOREIGN KEY (tour_id) REFERENCES tours(id)
                    )";
                    
                    if ($conn->query($sql) === TRUE) {
                        echo "<div class='bg-green-900 text-green-100 p-4 rounded mb-4'>
                            Bookings table created successfully
                        </div>";
                    }
                    
                    // Create payments table
                    $sql = "CREATE TABLE IF NOT EXISTS payments (
                        id INT(11) AUTO_INCREMENT PRIMARY KEY,
                        booking_id INT(11),
                        amount DECIMAL(10,2),
                        method VARCHAR(50),
                        transaction_id VARCHAR(100),
                        sender_number VARCHAR(20),
                        status ENUM('pending', 'completed', 'failed') DEFAULT 'pending',
                        payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (booking_id) REFERENCES bookings(id)
                    )";
                    
                    if ($conn->query($sql) === TRUE) {
                        echo "<div class='bg-green-900 text-green-100 p-4 rounded mb-4'>
                            Payments table created successfully
                        </div>";
                    }
                    
                    // Create settings table
                    $sql = "CREATE TABLE IF NOT EXISTS settings (
                        id INT(11) AUTO_INCREMENT PRIMARY KEY,
                        bkash_number VARCHAR(20),
                        nagad_number VARCHAR(20),
                        bank_name VARCHAR(100),
                        bank_account VARCHAR(50),
                        contact_email VARCHAR(100),
                        contact_phone VARCHAR(20),
                        app_name VARCHAR(100)
                    )";
                    
                    if ($conn->query($sql) === TRUE) {
                        echo "<div class='bg-green-900 text-green-100 p-4 rounded mb-4'>
                            Settings table created successfully
                        </div>";
                    }
                    
                    // Insert default admin
                    $default_pass = password_hash('admin123', PASSWORD_DEFAULT);
                    $sql = "INSERT INTO admin (username, password) VALUES ('admin', '$default_pass') 
                            ON DUPLICATE KEY UPDATE password='$default_pass'";
                    
                    if ($conn->query($sql) === TRUE) {
                        echo "<div class='bg-green-900 text-green-100 p-4 rounded mb-4'>
                            Default admin created (username: admin, password: admin123)
                        </div>";
                    }
                    
                    // Insert default settings
                    $sql = "INSERT INTO settings (bkash_number, nagad_number, bank_name, bank_account, contact_email, contact_phone, app_name) 
                            VALUES ('017XXXXXXXX', '017XXXXXXXX', 'Bangladesh Bank', '1234567890', 'contact@zxtourff.com', '017XXXXXXXX', 'Zx Tour FF') 
                            ON DUPLICATE KEY UPDATE app_name='Zx Tour FF'";
                    
                    $conn->query($sql);
                    
                    // Insert sample tours
                    $tours = [
                        ["Cox's Bazar Beach Tour", "Enjoy the longest sea beach in the world", "Cox's Bazar", "3 Days 2 Nights", 12000, 10000, "https://images.unsplash.com/photo-1593693399075-2e8ec6b80d8a?w=400", 15, 1],
                        ["Sundarbans Adventure", "Explore the mangrove forest and wildlife", "Khulna", "2 Days 1 Night", 8000, 7000, "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w-400", 20, 1],
                        ["Sylhet Tea Garden Tour", "Visit tea gardens and hills", "Sylhet", "4 Days 3 Nights", 15000, 13000, "https://images.unsplash.com/photo-1515098506762-79e138364b01?w=400", 10, 0]
                    ];
                    
                    foreach ($tours as $tour) {
                        $sql = "INSERT INTO tours (title, description, destination, duration, price, discount_price, image_url, available_seats, is_featured) 
                                VALUES ('$tour[0]', '$tour[1]', '$tour[2]', '$tour[3]', $tour[4], $tour[5], '$tour[6]', $tour[7], $tour[8]) 
                                ON DUPLICATE KEY UPDATE title='$tour[0]'";
                        $conn->query($sql);
                    }
                    
                    echo "<div class='bg-blue-900 text-blue-100 p-4 rounded mb-4'>
                        <h3 class='font-bold text-lg'>Installation Complete!</h3>
                        <p class='mt-2'>Database and tables have been created successfully.</p>
                        <p class='mt-2'><strong>Admin Login:</strong> admin / admin123</p>
                        <div class='mt-4 flex gap-4'>
                            <a href='login.php' class='bg-green-600 hover:bg-green-700 px-6 py-2 rounded-lg font-medium'>
                                Go to User Login
                            </a>
                            <a href='admin/login.php' class='bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded-lg font-medium'>
                                Go to Admin Login
                            </a>
                        </div>
                    </div>";
                    
                } else {
                    echo "<div class='bg-red-900 text-red-100 p-4 rounded mb-4'>
                        Error creating database: " . $conn->error . "
                    </div>";
                }
                
                $conn->close();
            } else {
            ?>
            <h2 class="text-2xl font-bold mb-6 text-center">System Requirements Check</h2>
            
            <div class="space-y-4 mb-8">
                <?php
                $requirements = [
                    'PHP Version (>= 7.4)' => version_compare(PHP_VERSION, '7.4.0', '>='),
                    'MySQLi Extension' => extension_loaded('mysqli'),
                    'GD Library' => extension_loaded('gd'),
                    'File Uploads' => ini_get('file_uploads'),
                    'Session Support' => function_exists('session_start')
                ];
                
                foreach ($requirements as $req => $status) {
                    $color = $status ? 'text-green-400' : 'text-red-400';
                    $icon = $status ? 'fa-check-circle' : 'fa-times-circle';
                    echo "<div class='flex items-center justify-between p-3 bg-gray-700 rounded-lg'>
                        <span>$req</span>
                        <i class='fas $icon $icon $color'></i>
                    </div>";
                }
                ?>
            </div>
            
            <form method="POST" class="space-y-6">
                <div class="bg-gray-700 p-4 rounded-lg">
                    <h3 class="font-bold text-lg mb-3">Database Configuration</h3>
                    <p class="text-gray-300 mb-4">Default MySQL configuration (XAMPP/WAMP):</p>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-sm font-medium mb-1">Host</label>
                            <input type="text" value="127.0.0.1" readonly class="w-full bg-gray-600 border border-gray-500 rounded px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium mb-1">Username</label>
                            <input type="text" value="root" readonly class="w-full bg-gray-600 border border-gray-500 rounded px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium mb-1">Password</label>
                            <input type="text" value="root" readonly class="w-full bg-gray-600 border border-gray-500 rounded px-3 py-2">
                        </div>
                    </div>
                </div>
                
                <div class="bg-yellow-900/30 border border-yellow-700 p-4 rounded-lg">
                    <h4 class="font-bold text-yellow-300 mb-2"><i class="fas fa-exclamation-triangle mr-2"></i>Important</h4>
                    <p class="text-yellow-200 text-sm">Make sure your MySQL server is running. For XAMPP, start Apache and MySQL services.</p>
                </div>
                
                <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                    <i class="fas fa-database mr-2"></i>Install Now
                </button>
            </form>
            <?php } ?>
        </div>
        
        <div class="text-center text-gray-500 text-sm">
            <p>Zx Tour FF &copy; <?php echo date('Y'); ?> | All Rights Reserved</p>
        </div>
    </div>
    
    <script>
        // Disable right-click
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });
        
        // Disable zoom
        document.addEventListener('wheel', function(e) {
            if (e.ctrlKey) {
                e.preventDefault();
            }
        }, { passive: false });
        
        // Disable keyboard zoom
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && (e.key === '+' || e.key === '-' || e.key === '0')) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>