<?php
$page_title = "Payment";
require_once 'common/config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$booking_id = isset($_GET['booking_id']) ? intval($_GET['booking_id']) : 0;

// Get booking details
$booking_query = $conn->prepare("SELECT b.*, t.title FROM bookings b 
                                JOIN tours t ON b.tour_id = t.id 
                                WHERE b.id = ? AND b.user_id = ?");
$booking_query->bind_param("ii", $booking_id, $_SESSION['user_id']);
$booking_query->execute();
$booking_result = $booking_query->get_result();

if ($booking_result->num_rows === 0) {
    redirect('my-bookings.php');
}

$booking = $booking_result->fetch_assoc();
$booking_query->close();

// Get payment settings
$settings_query = "SELECT * FROM settings LIMIT 1";
$settings_result = $conn->query($settings_query);
$settings = $settings_result->fetch_assoc();

// Handle payment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_method = sanitize($_POST['payment_method']);
    $transaction_id = sanitize($_POST['transaction_id']);
    $sender_number = sanitize($_POST['sender_number']);
    
    // Update booking with payment method
    $update_stmt = $conn->prepare("UPDATE bookings SET payment_method = ?, transaction_id = ? WHERE id = ?");
    $update_stmt->bind_param("ssi", $payment_method, $transaction_id, $booking_id);
    $update_stmt->execute();
    $update_stmt->close();
    
    // Insert payment record
    $payment_stmt = $conn->prepare("INSERT INTO payments (booking_id, amount, method, transaction_id, sender_number) 
                                    VALUES (?, ?, ?, ?, ?)");
    $payment_stmt->bind_param("idsss", $booking_id, $booking['total_amount'], $payment_method, $transaction_id, $sender_number);
    
    if ($payment_stmt->execute()) {
        // Redirect to bookings with success message
        $_SESSION['payment_success'] = true;
        redirect('my-bookings.php');
    }
    $payment_stmt->close();
}

require_once 'common/header.php';
?>

<div class="container mx-auto px-4 py-6 max-w-4xl">
    <h1 class="text-3xl font-bold mb-2">Complete Payment</h1>
    <p class="text-gray-400 mb-8">Pay using Bangladesh's trusted payment methods</p>
    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Booking Summary -->
        <div class="lg:col-span-2">
            <div class="bg-gray-800 rounded-xl p-6 mb-6">
                <h2 class="text-xl font-bold mb-4">Booking Summary</h2>
                <div class="space-y-4">
                    <div class="flex justify-between">
                        <span class="text-gray-400">Tour Package:</span>
                        <span class="font-medium"><?php echo htmlspecialchars($booking['title']); ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-400">Booking Date:</span>
                        <span class="font-medium"><?php echo date('d M Y', strtotime($booking['booking_date'])); ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-400">Number of Persons:</span>
                        <span class="font-medium"><?php echo $booking['persons']; ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-400">Status:</span>
                        <span class="bg-yellow-900 text-yellow-100 px-3 py-1 rounded-full text-sm">
                            <?php echo ucfirst($booking['status']); ?>
                        </span>
                    </div>
                    <div class="pt-4 border-t border-gray-700">
                        <div class="flex justify-between text-lg">
                            <span class="text-gray-300">Total Amount:</span>
                            <span class="text-2xl font-bold text-green-400">৳<?php echo number_format($booking['total_amount']); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Payment Form -->
            <div class="bg-gray-800 rounded-xl p-6">
                <h2 class="text-xl font-bold mb-6">Select Payment Method</h2>
                <form method="POST">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                        <label class="relative">
                            <input type="radio" name="payment_method" value="bkash" class="hidden peer" required>
                            <div class="bg-gray-700 border-2 border-gray-600 rounded-xl p-4 text-center cursor-pointer 
                                      hover:border-green-500 peer-checked:border-green-500 peer-checked:bg-green-900/20 transition">
                                <div class="w-12 h-12 bg-red-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                                    <i class="fas fa-mobile-alt text-white text-xl"></i>
                                </div>
                                <div class="font-bold">Bkash</div>
                                <div class="text-sm text-gray-400 mt-1"><?php echo $settings['bkash_number']; ?></div>
                            </div>
                        </label>
                        
                        <label class="relative">
                            <input type="radio" name="payment_method" value="nagad" class="hidden peer">
                            <div class="bg-gray-700 border-2 border-gray-600 rounded-xl p-4 text-center cursor-pointer 
                                      hover:border-green-500 peer-checked:border-green-500 peer-checked:bg-green-900/20 transition">
                                <div class="w-12 h-12 bg-green-700 rounded-lg flex items-center justify-center mx-auto mb-3">
                                    <i class="fas fa-wallet text-white text-xl"></i>
                                </div>
                                <div class="font-bold">Nagad</div>
                                <div class="text-sm text-gray-400 mt-1"><?php echo $settings['nagad_number']; ?></div>
                            </div>
                        </label>
                        
                        <label class="relative">
                            <input type="radio" name="payment_method" value="bank" class="hidden peer">
                            <div class="bg-gray-700 border-2 border-gray-600 rounded-xl p-4 text-center cursor-pointer 
                                      hover:border-green-500 peer-checked:border-green-500 peer-checked:bg-green-900/20 transition">
                                <div class="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-3">
                                    <i class="fas fa-university text-white text-xl"></i>
                                </div>
                                <div class="font-bold">Bank Transfer</div>
                                <div class="text-sm text-gray-400 mt-1"><?php echo $settings['bank_name']; ?></div>
                            </div>
                        </label>
                    </div>
                    
                    <div id="paymentDetails" class="space-y-4 hidden">
                        <div>
                            <label class="block text-sm font-medium mb-2">Transaction ID</label>
                            <input type="text" name="transaction_id" required 
                                   class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500"
                                   placeholder="Enter transaction ID">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium mb-2">Your Mobile Number</label>
                            <input type="text" name="sender_number" required 
                                   class="w-full bg-gray-700 border border-gray-600 rounded-lg px-4 py-3 focus:outline-none focus:border-green-500"
                                   placeholder="01XXXXXXXXX">
                        </div>
                        
                        <div class="bg-blue-900/30 border border-blue-700 p-4 rounded-lg">
                            <h4 class="font-bold text-blue-300 mb-2"><i class="fas fa-info-circle mr-2"></i>Important Instructions</h4>
                            <ul class="text-blue-200 text-sm space-y-1">
                                <li>• Send exact amount: ৳<?php echo number_format($booking['total_amount']); ?></li>
                                <li>• Use the transaction ID as reference</li>
                                <li>• Keep screenshot of payment confirmation</li>
                                <li>• Payment verification may take 1-2 hours</li>
                            </ul>
                        </div>
                        
                        <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-4 px-6 rounded-lg text-lg transition duration-300">
                            <i class="fas fa-check-circle mr-2"></i>Confirm Payment
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Payment Instructions -->
        <div class="space-y-6">
            <!-- Bkash Instructions -->
            <div class="bg-gray-800 rounded-xl p-5">
                <div class="flex items-center mb-4">
                    <div class="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-mobile-alt text-white"></i>
                    </div>
                    <h3 class="font-bold">Bkash Payment</h3>
                </div>
                <ol class="text-sm text-gray-300 space-y-2">
                    <li>1. Go to bKash Menu</li>
                    <li>2. Select "Send Money"</li>
                    <li>3. Enter: <?php echo $settings['bkash_number']; ?></li>
                    <li>4. Enter Amount: ৳<?php echo number_format($booking['total_amount']); ?></li>
                    <li>5. Enter Reference: Your Name</li>
                    <li>6. Enter your PIN</li>
                </ol>
            </div>
            
            <!-- Nagad Instructions -->
            <div class="bg-gray-800 rounded-xl p-5">
                <div class="flex items-center mb-4">
                    <div class="w-10 h-10 bg-green-700 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-wallet text-white"></i>
                    </div>
                    <h3 class="font-bold">Nagad Payment</h3>
                </div>
                <ol class="text-sm text-gray-300 space-y-2">
                    <li>1. Open Nagad App</li>
                    <li>2. Select "Send Money"</li>
                    <li>3. Enter: <?php echo $settings['nagad_number']; ?></li>
                    <li>4. Enter Amount: ৳<?php echo number_format($booking['total_amount']); ?></li>
                    <li>5. Add Reference: Booking #<?php echo $booking_id; ?></li>
                    <li>6. Confirm with PIN</li>
                </ol>
            </div>
            
            <!-- Bank Instructions -->
            <div class="bg-gray-800 rounded-xl p-5">
                <div class="flex items-center mb-4">
                    <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-university text-white"></i>
                    </div>
                    <h3 class="font-bold">Bank Transfer</h3>
                </div>
                <div class="text-sm text-gray-300 space-y-2">
                    <p><strong>Bank:</strong> <?php echo $settings['bank_name']; ?></p>
                    <p><strong>Account:</strong> <?php echo $settings['bank_account']; ?></p>
                    <p><strong>Amount:</strong> ৳<?php echo number_format($booking['total_amount']); ?></p>
                    <p><strong>Reference:</strong> Tour Booking</p>
                </div>
            </div>
            
            <!-- Support -->
            <div class="bg-purple-900/30 border border-purple-700 rounded-xl p-5">
                <h3 class="font-bold mb-3 text-purple-300"><i class="fas fa-headset mr-2"></i>Need Help?</h3>
                <p class="text-sm text-purple-200 mb-2">Contact our support team:</p>
                <div class="text-sm text-gray-300">
                    <p><i class="fas fa-phone mr-2"></i> <?php echo $settings['contact_phone']; ?></p>
                    <p><i class="fas fa-envelope mr-2"></i> <?php echo $settings['contact_email']; ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Show payment details when method is selected
    document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
        radio.addEventListener('change', function() {
            document.getElementById('paymentDetails').classList.remove('hidden');
        });
    });
</script>

<?php require_once 'common/bottom.php'; ?>